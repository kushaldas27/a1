#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {

    printf("Be patient, the program will take around 7 seconds to run.\n");
    printf("At the end you can do \"cat results.out\" to see the result.\n");

    //
    // Add code here to pipe from ./slow “This is a test sentence” to ./talk and redirect
    // output of ./talk to results.out
    // I.e. your program should do the equivalent of ./slow “This is a test sentence” | ./talk > results.out
    // WITHOUT using | and > from the shell.
    //

}
