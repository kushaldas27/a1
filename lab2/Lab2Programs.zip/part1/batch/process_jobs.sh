#!/bin/bash

# Check if we have enough arguments

# Iterate over every job directory
    # Compile C code
    # Print compile error message to output file
    # Generate output from C code using *.in files
    # Measure the execution time
    # Record any runtime errors

# Generate a summary report
