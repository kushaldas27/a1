
int sum(int [], int);
